# ZKLiveDataBus
ZKLiveDataBus


## 事件总线说明

https://www.cnblogs.com/meituantech/p/9376449.html

## 开源项目地址

https://github.com/JeremyLiao/LiveEventBus

