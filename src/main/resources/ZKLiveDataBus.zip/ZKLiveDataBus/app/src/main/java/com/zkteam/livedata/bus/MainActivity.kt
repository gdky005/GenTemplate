package com.zkteam.livedata.bus

import android.os.Bundle
import android.view.View
import com.zkteam.sdk.base.ZKBaseActivity

class MainActivity : ZKBaseActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_main
    }

    override fun initData(bundle: Bundle?) {

    }

    override fun initLifecycleObserve() {

    }

    override fun initListener() {

    }

    override fun initViews(contentView: View) {

    }

    override fun onDebouncingClick(view: View) {

    }
}
